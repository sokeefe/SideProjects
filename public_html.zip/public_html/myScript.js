
// Keep everything in anonymous function, called on window load.
if(window.addEventListener) {
window.addEventListener('load', function () {
  var canvas, context, canvaso, contexto, undoButton, width, height; 

  // The active tool instance.
  var tool;
  var tool_default = 'pencil';
  
  function init () {
    // Find the canvas element.
    canvaso = document.getElementById('parentCanvas');
    
    // Get the 2D canvas context.
    contexto = canvaso.getContext('2d');
    // Add the temporary canvas.
    var container = canvaso.parentNode;
    canvas = document.createElement('canvas');
    canvas.id     = 'imageTemp';
    canvas.width  = canvaso.width;
    canvas.height = canvaso.height;
    container.appendChild(canvas);
    context = canvas.getContext('2d');
    // Get the tool select input.
    var tool_select = document.getElementById('dtool');
    tool_select.addEventListener('change', ev_tool_change, false);

    // Activate the default tool.
    if (tools[tool_default]) {
      tool = new tools[tool_default]();
      tool_select.value = tool_default;
    }
    
    undoButton = document.getElementById('undo');
    // Attach the mousedown, mousemove and mouseup event listeners.
    canvas.addEventListener('mousedown', ev_canvas, false);
    canvas.addEventListener('mousemove', ev_canvas, false);
    canvas.addEventListener('mouseup',   ev_canvas, false);
    undoButton.addEventListener('click', undo);
  }

  // The general-purpose event handler. This function just determines the mouse 
  // position relative to the canvas element.
  function ev_canvas (ev) {
    if (ev.layerX || ev.layerX == 0) { // Firefox
      ev._x = ev.layerX;
      ev._y = ev.layerY;
    } else if (ev.offsetX || ev.offsetX == 0) { // Opera
      ev._x = ev.offsetX;
      ev._y = ev.offsetY;
    }

    // Call the event handler of the tool.
    var func = tool[ev.type];
    if (func) {
      func(ev);
    }
  }

  // The event handler for any changes made to the tool selector.
  function ev_tool_change (ev) {
    if (tools[this.value]) {
      tool = new tools[this.value]();
    }
  }
  

  // This function draws the #imageTemp canvas on top of #parentCanvas, after which 
  // #imageTemp is cleared. This function is called each time when the user 
  // completes a drawing operation.
  function img_update () {
        contexto.drawImage(canvas, 0, 0);
        context.clearRect(0, 0, canvas.width, canvas.height);
  }
  function undo (){
        context.clearRect(0, 0, canvas.width, canvas.height);
        contexto.clearRect(0, 0, canvas.width, canvas.height);
  }
  // This object holds the implementation of each drawing tool.
  var tools = {};

  // The drawing pencil.
  tools.pencil = function () {
    var tool = this;
    this.started = false;

    // This is called when you start holding down the mouse button.
    // This starts the pencil drawing.
    this.mousedown = function (ev) {
        context.beginPath();
        context.moveTo(ev._x, ev._y);
        tool.started = true;
    };

    // This function is called every time you move the mouse. Obviously, it only 
    // draws if the tool.started state is set to true (when you are holding down 
    // the mouse button).
    this.mousemove = function (ev) {
      if (tool.started) {  
        context.fillStyle = document.getElementById('dfillcolor').value;
        context.strokeStyle = document.getElementById('dlinecolor').value;
        context.lineWidth = document.getElementById('dthickness').value;
        context.globalAlpha = document.getElementById('dopacity').value;
        context.lineTo(ev._x, ev._y);
        context.stroke();
      }
    };

    // This is called when you release the mouse button.
    this.mouseup = function (ev) {
      if (tool.started) {
        tool.mousemove(ev);
        tool.started = false;
        img_update();
      }
    };
  };

  // The rectangle tool.
  tools.rect = function () {
    var tool = this;
    this.started = false;

      this.mousedown = function (ev) {
      tool.started = true;
      tool.x0 = ev._x;
      tool.y0 = ev._y;
    };

     this.mousemove = function (ev) {
      if (!tool.started) {
        return;
     }

      var x = Math.min(ev._x,  tool.x0),
          y = Math.min(ev._y,  tool.y0),
          w = Math.abs(ev._x - tool.x0),
          h = Math.abs(ev._y - tool.y0);

      context.clearRect(0, 0, canvas.width, canvas.height);
      context.fillStyle = document.getElementById('dfillcolor').value;
      context.strokeStyle = document.getElementById('dlinecolor').value;
      context.fillStyle = document.getElementById('dfillcolor').value;
      context.strokeStyle = document.getElementById('dlinecolor').value;
      context.lineWidth = document.getElementById('dthickness').value;
      context.globalAlpha = document.getElementById('dopacity').value;
      if (!w || !h) {
        return;
      }
      
      
      if(document.getElementById('dfill').value == 'filled'){
        context.fillRect(x, y, w, h);
      }
      else{
        context.strokeRect(x, y, w, h); 
      }
    };

    this.mouseup = function (ev) {
      if (tool.started) {
        tool.mousemove(ev);
        tool.started = false;
        img_update();
      }
    };
  };

  // The line tool.
  tools.ellipse = function () {
    var tool = this;
    this.started = false;

    this.mousedown = function (ev) {
      tool.started = true;
      tool.x0 = ev._x;
      tool.y0 = ev._y;
      width = document.getElementById('width').value;
      height = document.getElementById('height').value;
    };

     this.mousemove = function (ev) {
      if (!tool.started) {
        return;
      }
     
     context.clearRect(0, 0, canvas.width, canvas.height);
     context.beginPath();
  
        context.moveTo(ev._x, ev._y - height/2); // A1

        context.bezierCurveTo(
          ev._x + width/2, ev._y - height/2, // C1
          ev._x + width/2, ev._y + height/2, // C2
          ev._x, ev._y + height/2); // A2

        context.bezierCurveTo(
          ev._x - width/2, ev._y + height/2, // C3
          ev._x - width/2, ev._y - height/2, // C4
          ev._x, ev._y - height/2); // A1

         context.closePath();
        if(document.getElementById('dfill').value == 'filled'){
            context.fillStyle = document.getElementById('dfillcolor').value;
            context.fill();
        }
       
      

      
      
    };

    this.mouseup = function (ev) {
      if (tool.started) {
        tool.mousemove(ev);
        tool.started = false;
        img_update();
      }
    };
  };
  
  
  init();

}, false); }
